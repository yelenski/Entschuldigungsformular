const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
const entschuldigungsFormularController = require("../controller/05_EntschuldigungsFormularController");

const app = express();
const port = 3000;


app.use(cors({
    origin: function (origin, callback) {
        if (!origin || origin.startsWith("http://localhost") || origin.startsWith("http://127.0.0.1")) {
            callback(null, true);
        } else {
            callback(new Error("Nicht erlaubt durch CORS"));
        }
    },
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allowedHeaders: ["Origin", "X-Requested-With", "Content-Type", "Accept"]
}));

app.use(express.json());

// Statische Dateien aus dem Hauptverzeichnis bereitstellen
app.use(express.static(path.join(__dirname, "../")));

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "../index.html"));
});

// API-Endpunkte
app.get("/entschuldigungsformular/getall", entschuldigungsFormularController.getAll);
app.post("/entschuldigungsformular/addone", (req, res) => {
    try {
        const formData = {
            name: req.body.name || "N/A",
            vorname: req.body.vorname || "N/A",
            beruf: req.body.beruf || "N/A",
            klasse: req.body.klasse || "N/A",
            grund: req.body.grund || "N/A",
            telefonP: req.body.telefonP || "N/A",
            telefonG: req.body.telefonG || "N/A",
            ortDatum: req.body.ortDatum || "N/A",
            muendig: req.body.muendig || false
        };
        console.log("Formulardaten empfangen:", formData);

        const filePath = path.join(__dirname, "entschuldigung.json");

        let existingData = [];
        try {
            if (fs.existsSync(filePath)) {
                const rawData = fs.readFileSync(filePath, 'utf8');
                if (rawData.trim() !== "") {
                    existingData = JSON.parse(rawData);
                }
            } else {
                fs.writeFileSync(filePath, JSON.stringify([], null, 2), 'utf8');
            }
        } catch (err) {
            console.error("Fehler beim Lesen der JSON-Datei:", err);
            existingData = [];
        }

        existingData.push(formData);
        fs.writeFileSync(filePath, JSON.stringify(existingData, null, 2), 'utf8');
        console.log("Daten erfolgreich gespeichert in entschuldigung.json");

        res.status(200).json({ message: "Daten erfolgreich gespeichert" });
    } catch (error) {
        console.error("Fehler beim Speichern der Daten:", error);
        res.status(500).json({ message: "Fehler beim Speichern der Daten" });
    }
});

app.listen(port, () => {
    console.log(`Server läuft auf http://localhost:${port}`);
});