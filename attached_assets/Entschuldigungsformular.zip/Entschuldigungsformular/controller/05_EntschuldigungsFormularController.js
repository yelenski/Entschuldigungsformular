const data = {};

module.exports = {
    async getAll(req, res) {
        try {
            const allElements = Object.keys(data).map(key => ({ [key]: data[key] }));
            res.json({
                err: false,
                elements: allElements,
            });
        } catch (error) {
            console.error(error);
            res.json({
                err: true,
                msg: "Serverfehler beim Abrufen",
            });
        }
    },

    async addOne(req, res) {
        try {
            const { name, beruf, grund } = req.body;
            if (name && beruf && grund) {
                data[name] = { Beruf: beruf, Grund: grund };
                res.json({ err: false, message: "Entschuldigung hinzugefügt" });
            } else {
                res.json({ err: true, msg: "Ungültige Eingabe" });
            }
        } catch (error) {
            console.error(error);
            res.json({
                err: true,
                msg: "Serverfehler beim Hinzufügen",
            });
        }
    }
};
