import { } from './utils.js';

document.addEventListener("DOMContentLoaded", function () {
    initSignaturePad();

    const form = document.getElementById("formEntschuldigung");
    if (!form) {
        console.warn("Formular mit der ID 'formEntschuldigung' nicht gefunden.");
        return;
    }

    // Eventlistener für das Formular
    form.addEventListener("submit", async function (event) {
        event.preventDefault();

        try {
            const formData = getFormData();
            if (!formData) {
                alert("Bitte alle Felder ausfüllen.");
                return;
            }

            await sendFormData(formData);
            showConfirmation();
            resetForm();
        } catch (error) {
            console.error("Fehler beim Senden der Daten:", error.message);
            alert("Fehler beim Senden: " + error.message);
        }
    });
});

// 🔧 Formular-Daten sammeln
function getFormData() {
    const fields = ["name", "vorname", "beruf", "klasse", "grund", "telefonP", "telefonG", "ort", "datum"];
    const formData = {};

    for (const field of fields) {
        const element = document.getElementById(field);
        if (!element || !element.value.trim()) {
            console.warn(`Element mit ID '${field}' nicht gefunden oder leer.`);
            return null;
        }
        formData[field] = element.value;
    }

    formData.muendig = document.getElementById("muendig")?.checked || false;
    formData.absenzDaten = collectAbsenzDaten();
    formData.unterschrift = getSignatureDataURL();
    return formData;
}

// 📅 Absenzdaten sammeln
function collectAbsenzDaten() {
    const absenzDaten = [];
    for (let i = 1; i <= 6; i++) {
        const datum = document.getElementById(`datum${i}`)?.value || "";
        const lehrperson = document.getElementById(`filterLehrer${i}`)?.value || "";
        const lektion = document.getElementById(`lektion${i}`)?.value || "";

        if (datum || lehrperson || lektion) {
            absenzDaten.push({ datum, lehrperson, lektion });
        }
    }
    return absenzDaten;
}

// 📤 Formular-Daten senden
async function sendFormData(formData) {
    try {
        const response = await fetch("http://localhost:3000/entschuldigungsformular/addone", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(formData),
        });

        if (!response.ok) {
            throw new Error(`Server antwortete mit Status: ${response.status}`);
        }

        const result = await response.json();
        await saveToJSON(formData, 'entschuldigung.json');
        alert(result.message);
    } catch (error) {
        throw new Error("Fehler beim Senden der Daten: " + error.message);
    }
}

// 💾 Daten in JSON speichern
async function saveToJSON(data, fileName) {
    try {
        const response = await fetch(`/saveData?fileName=${fileName}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        });

        if (!response.ok) {
            throw new Error("Fehler beim Speichern der Daten.");
        }
    } catch (error) {
        console.error("Speicherfehler:", error);
    }
}

// ✅ Bestätigung anzeigen
function showConfirmation() {
    const confirmationMessage = document.getElementById("confirmationMessage");
    if (confirmationMessage) {
        confirmationMessage.style.display = "block";
        setTimeout(() => {
            confirmationMessage.style.display = "none";
        }, 3000);
    }
}

// 📝 Formular zurücksetzen
function resetForm() {
    const form = document.getElementById("formEntschuldigung");
    if (form) {
        form.reset();
        clearSignature();
        resetAbsenzTabelle();
    }
    console.log("Formular erfolgreich zurückgesetzt.");
}

// 📝 Absenz-Tabelle zurücksetzen
function resetAbsenzTabelle() {
    for (let i = 1; i <= 6; i++) {
        document.getElementById(`datum${i}`)?.value = "";
        document.getElementById(`filterLehrer${i}`)?.value = "";
        document.getElementById(`lektion${i}`)?.value = "";
    }
    console.log("Absenz-Tabelle zurückgesetzt");
}

// ✒️ Signaturpad initialisieren nach LogRocket-Methode
function initSignaturePad() {
    const canvas = document.getElementById("signature-pad");
    if (!canvas) {
        console.warn("Signaturpad nicht gefunden.");
        return;
    }

    // Canvas an Bildschirm anpassen
    function resizeCanvas() {
        const ratio = Math.max(window.devicePixelRatio || 1, 1);
        canvas.width = canvas.offsetWidth * ratio;
        canvas.height = canvas.offsetHeight * ratio;
        const context = canvas.getContext("2d");
        context.scale(ratio, ratio);
        context.clearRect(0, 0, canvas.width, canvas.height);
    }

    window.addEventListener("resize", resizeCanvas);
    resizeCanvas();  // Initiales Resizing

    const signaturePad = new SignaturePad(canvas, {
        minWidth: 1,
        maxWidth: 3,
        penColor: "black",
        backgroundColor: "rgba(255, 255, 255, 0)"
    });

    if (!signaturePad) {
        console.warn("SignaturePad konnte nicht initialisiert werden.");
        return;
    }

    // Detailliertes Logging für Zeichnen-Events
    signaturePad.onBegin = () => console.log("Zeichnen gestartet.");
    signaturePad.onEnd = () => console.log("Zeichnen beendet.");

    canvas.addEventListener("pointerdown", function (event) {
        console.log("Pointer Down:", event);
    });

    canvas.addEventListener("pointermove", function (event) {
        console.log("Pointer Move:", event);
    });

    canvas.addEventListener("pointerup", function (event) {
        console.log("Pointer Up:", event);
    });

    signaturePad.onBegin = function () {
        console.log("Stroke started");
    };

    signaturePad.onEnd = function () {
        console.log("Stroke ended");
    };

    console.log("SignaturePad erfolgreich initialisiert.");

    // Touch events to prevent scrolling while drawing
    canvas.addEventListener("touchstart", function (event) {
        event.preventDefault();
    });
    canvas.addEventListener("touchmove", function (event) {
        event.preventDefault();
    });

    const clearButton = document.getElementById("clear-signature");
    if (clearButton) {
        clearButton.addEventListener("click", function () {
            signaturePad.clear();
        });
    }

    if (signaturePad.isEmpty()) {
        console.log("Bitte unterschreiben.");
    }
}

// ✒️ Signatur löschen nach LogRocket-Methode
function clearSignature() {
    console.log("Signatur wird gelöscht...");
    const canvas = document.getElementById("signature-pad");
    if (canvas) {
        const signaturePad = new SignaturePad(canvas, {
            minWidth: 1,
            maxWidth: 3,
            penColor: "black",
            backgroundColor: "rgba(255, 255, 255, 0)"
        });
        if (!signaturePad) {
            console.warn("SignaturePad konnte beim Löschen nicht initialisiert werden.");
            return;
        }
        signaturePad.clear();
    }
}

// 📜 Unterschrift als Bild abrufen
function getSignatureDataURL() {
    const canvas = document.getElementById("signature-pad");
    if (!canvas) {
        console.warn("Canvas für Signatur nicht gefunden.");
        return "";
    }

    const context = canvas.getContext("2d");
    if (context.getImageData(0, 0, canvas.width, canvas.height).data.some(channel => channel !== 0)) {
        return canvas.toDataURL("image/png");
    } else {
        console.warn("Leere Signatur.");
        return "";
    }
}