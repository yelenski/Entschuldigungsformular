// Index-Seiten Logik (Login-Bereich)

async function sendLoginData(username, role) {
    try {
        const response = await fetch("http://127.0.0.1:3000/entschuldigungsformular/addone", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ username, role }),
        });
        const result = await response.json();
        console.log("Login erfolgreich:", result.message);
    } catch (error) {
        console.error("Fehler beim Login:", error);
    }
}

document.getElementById("loginForm").addEventListener("submit", async function(event) {
    event.preventDefault();
    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    if (username && password) {
        localStorage.setItem("is_logged_in", "true");
        showLoginConfirmation();
        await sendLoginData(username, role);
        if (role === "schueler") {
            window.location.href = "entschuldigung.html";
        } else {
            window.location.href = "uebersicht.html";
        }
    } else {
        alert("Bitte alle Felder ausfüllen.");
    }
});

function showLoginConfirmation() {
    const confirmation = document.getElementById("confirmationMessage");
    confirmation.style.display = "block";
    setTimeout(() => { confirmation.style.display = "none"; }, 3000);
}