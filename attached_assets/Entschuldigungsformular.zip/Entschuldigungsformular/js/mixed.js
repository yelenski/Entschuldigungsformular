export function initLehrpersonenDropdowns() {
    const lehrpersonen = [
        "Fabienne Affolter", "Jacqueline Amsler", "Arta Arifaj", "Roland Bacher",
        "Manuel Bachofner", "Gerda Baumgartner", "Gilbert Bernoulli", "Sylvie Bonaparte",
        "Carla Bonetti", "Remo Borioli", "Stefan Brand", "Thomas Brenner", "Erich Brugger",
        "Jürg Brunner", "Thomas Brunner", "Luana Bucefari", "Felix Buchenberger", 
        "Markus Buntschu", "Alain Burger", "Daniel Bühlmann", "Alexandra Bühlmann", 
        "Sandra Christen", "Benjamin Fritz", "Daniel Frei", "Martin Huber", 
        "Petra Kaufmann", "Lukas Keller", "Andrea Müller", "Sophie Schneider", 
        "Kevin Weber", "Simon Zimmermann", "Wojciech Kozlowski", "Nicolas Müller", 
        "Larisa Wick-Nussbaum", "Urs Graf"
    ];

    // Wähle alle Dropdowns mit der Klasse 'filterLehrer' oder deren Name mit 'lehrperson' beginnt
    const dropdowns = document.querySelectorAll("select.filterLehrer, select[name^='lehrperson']");

    // Durchlaufe jedes Dropdown-Element
    dropdowns.forEach(dropdown => {
        // Entferne vorherige Optionen, um Duplikate zu vermeiden
        dropdown.innerHTML = '';

        // Setze die Standardoption
        const defaultOption = document.createElement("option");
        defaultOption.value = "";
        defaultOption.textContent = "Bitte auswählen";
        defaultOption.disabled = true;
        defaultOption.selected = true;
        defaultOption.hidden = true;
        dropdown.appendChild(defaultOption);

        // Füge die Lehrpersonen hinzu
        lehrpersonen.forEach((lehrer) => {
            const option = document.createElement("option");
            option.value = lehrer.toLowerCase().replace(/\s+/g, "_");
            option.textContent = lehrer;
            dropdown.appendChild(option);
        });

        // Korrigiere das Dropdown-Verhalten, um die Auswahl zu ermöglichen
        dropdown.addEventListener("focus", () => {
            if (dropdown.selectedIndex === 0) {
                dropdown.selectedIndex = -1;
            }
        });

        // Überprüfe die Auswahl und aktiviere die Auswahlmöglichkeit
        dropdown.addEventListener("change", (event) => {
            if (event.target.value !== "") {
                dropdown.classList.remove("invalid");
            } else {
                dropdown.classList.add("invalid");
            }
        });
    });
}

// Aufruf beim Laden der Seite
document.addEventListener("DOMContentLoaded", initLehrpersonenDropdowns);
