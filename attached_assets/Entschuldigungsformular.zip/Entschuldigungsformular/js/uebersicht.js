const form = document.getElementById("myForm");
form.addEventListener("submit", function(event) {
    event.preventDefault();

    const formData = {
        name: document.getElementById("name") ? document.getElementById("name").value : "",
        vorname: document.getElementById("vorname") ? document.getElementById("vorname").value : "",
        beruf: document.getElementById("filterBeruf") ? document.getElementById("filterBeruf").value : "",
        klasse: document.getElementById("filterKlasse") ? document.getElementById("filterKlasse").value : "",
        grund: document.getElementById("grund") ? document.getElementById("grund").value : "",
        telefonP: document.getElementById("telefonP") ? document.getElementById("telefonP").value : "",
        telefonG: document.getElementById("telefonG") ? document.getElementById("telefonG").value : "",
        ortDatum: document.getElementById("ortDatum") ? document.getElementById("ortDatum").value : "",
        muendig: document.getElementById("muendig") ? document.getElementById("muendig").checked : false
    };

    fetch("/entschuldigungsformular/addone", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
    })
    .then(response => response.json())
    .then(data => {
        if (data.message) {
            form.reset(); // Reset native form fields

            // Clear signature canvas
            const canvas = document.getElementById("signatureCanvas");
            if (canvas && canvas.getContext) {
                const ctx = canvas.getContext("2d");
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }

            // Reset checkboxes within the form
            document.querySelectorAll("#myForm input[type=checkbox]").forEach(cb => cb.checked = false);
        }
    })
    .catch(error => console.error("Fehler beim Absenden des Formulars:", error));
});